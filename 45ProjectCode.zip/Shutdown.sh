./apache-tomcat-9.0.27/bin/shutdown.sh
